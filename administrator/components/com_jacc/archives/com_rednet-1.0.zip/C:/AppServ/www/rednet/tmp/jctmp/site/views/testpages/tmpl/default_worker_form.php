<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<h1>This is Worker form</h1>

papi cholo