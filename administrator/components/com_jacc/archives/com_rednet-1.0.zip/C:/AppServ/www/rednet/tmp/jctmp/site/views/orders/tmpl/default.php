<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>"><h2><?php echo $this->params->get('page_title');  ?></h2></div>
<h3><?php echo $this->item->name; ?></h3>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	
	<div>
		Name: <?php echo $this->item->name; ?>
	</div>
	<div>
		Order_no: <?php echo $this->item->order_no; ?>
	</div>
	<div>
		Type_order: <?php echo $this->item->type_order; ?>
	</div>
	<div>
		Type_if_other: <?php echo $this->item->type_if_other; ?>
	</div>
	<div>
		No_of_men: <?php echo $this->item->no_of_men; ?>
	</div>
	<div>
		No_of_trucks: <?php echo $this->item->no_of_trucks; ?>
	</div>
	<div>
		Truck_requirments: <?php echo $this->item->truck_requirments; ?>
	</div>
	<div>
		Out_of_town: <?php echo $this->item->out_of_town; ?>
	</div>
	<div>
		Instruction_file: <?php echo $this->item->instruction_file; ?>
	</div>
	<div>
		Id: <?php echo $this->item->id; ?>
	</div>

</div>
