<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_ ( 'behavior.formvalidation' );

?>

<div style="margin-left: 50px!important">
<jdoc:include type="message" />
</div>