CREATE TABLE IF NOT EXISTS `#__reportmaster` (
  `id` int(11) NOT NULL auto_increment,
  `order_id` int(11) NOT NULL,
  `departure_time` time NOT NULL,
  `return_time` time NOT NULL,
  `total_work_hours_billed` time NOT NULL,
  `paid_hours` time NOT NULL,
  `client_start` time NOT NULL,
  `client_end` time NOT NULL,
  `travel_time_billed` time NOT NULL,
  `travel_leak` time NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

