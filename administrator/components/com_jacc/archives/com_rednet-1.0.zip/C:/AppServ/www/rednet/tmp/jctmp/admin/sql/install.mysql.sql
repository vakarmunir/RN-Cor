CREATE TABLE IF NOT EXISTS `#__orders` (
  `id` int(11) NOT NULL auto_increment,
  `order_no` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_order` date NOT NULL,
  `type_order` varchar(255) NOT NULL,
  `type_if_other` varchar(255) NOT NULL,
  `no_of_men` varchar(255) NOT NULL,
  `no_of_trucks` varchar(255) NOT NULL,
  `truck_requirments` varchar(255) NOT NULL,
  `out_of_town` varchar(255) NOT NULL,
  `departure_time` time NOT NULL,
  `deposite` float NOT NULL,
  `is_addon` int(11) NOT NULL,
  `addon_time` time NOT NULL,
  `instruction_file` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `parent_order` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `#__resourcesmap` (
  `id` int(11) NOT NULL auto_increment,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `truck` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `#__user_availabilitycalendar` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `availability_date` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `#__vehicles_fleet` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `out_of_service` varchar(255) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `#__worker_role` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `#__workers` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `s_n` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `start_date` datetime NOT NULL,
  `dl_no` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cell` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `shirt_size` varchar(255) NOT NULL,
  `pant_leg` varchar(255) NOT NULL,
  `waist` varchar(255) NOT NULL,
  `receive_update_by` varchar(255) NOT NULL,
  `desired_shift` varchar(255) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `updated_date` datetime NOT NULL,
  `active_status` int(11) NOT NULL,
  `verified_status` int(11) NOT NULL,
  `verification_code` varchar(255) NOT NULL,
  `initial` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

