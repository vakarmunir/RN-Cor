DROP TABLE IF EXISTS #__worker_role;
DROP TABLE IF EXISTS #__workers;
