DROP TABLE IF EXISTS #__orders;
DROP TABLE IF EXISTS #__resourcesmap;
DROP TABLE IF EXISTS #__user_availabilitycalendar;
DROP TABLE IF EXISTS #__vehicles_fleet;
DROP TABLE IF EXISTS #__worker_role;
DROP TABLE IF EXISTS #__workers;
