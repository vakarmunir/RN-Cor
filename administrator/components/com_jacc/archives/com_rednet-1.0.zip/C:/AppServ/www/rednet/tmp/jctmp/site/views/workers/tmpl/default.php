<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>"><h2><?php echo $this->params->get('page_title');  ?></h2></div>
<h3><?php echo $this->item->first_name; ?></h3>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	
	<div>
		First_name: <?php echo $this->item->first_name; ?>
	</div>
	<div>
		Last_name: <?php echo $this->item->last_name; ?>
	</div>
	<div>
		S_n: <?php echo $this->item->s_n; ?>
	</div>
	<div>
		Dl_no: <?php echo $this->item->dl_no; ?>
	</div>
	<div>
		Class: <?php echo $this->item->class; ?>
	</div>
	<div>
		Status: <?php echo $this->item->status; ?>
	</div>
	<div>
		Email: <?php echo $this->item->email; ?>
	</div>
	<div>
		Cell: <?php echo $this->item->cell; ?>
	</div>
	<div>
		Home: <?php echo $this->item->home; ?>
	</div>
	<div>
		Shirt_size: <?php echo $this->item->shirt_size; ?>
	</div>
	<div>
		Pant_leg: <?php echo $this->item->pant_leg; ?>
	</div>
	<div>
		Waist: <?php echo $this->item->waist; ?>
	</div>
	<div>
		Receive_update_by: <?php echo $this->item->receive_update_by; ?>
	</div>
	<div>
		Desired_shift: <?php echo $this->item->desired_shift; ?>
	</div>
	<div>
		Updated_by: <?php echo $this->item->updated_by; ?>
	</div>
	<div>
		Verification_code: <?php echo $this->item->verification_code; ?>
	</div>
	<div>
		Initial: <?php echo $this->item->initial; ?>
	</div>
	<div>
		Id: <?php echo $this->item->id; ?>
	</div>

</div>
